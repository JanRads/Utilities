USE dbmSemanticAnalytics
GO
 
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Set nocount on
DECLARE @RelationTipe INT

SELECT @RelationTipe = AdminCodeKey
FROM Dim.AdminCodes
WHERE (Baseline_Code = N'GPCP')



SELECT 
--[id_Patient],
P.[FirstName],
--[provider_Related],
C.[FullName],
[date_From],
[date_To]
FROM [Factless].[PatientProviderRelations] A
 INNER JOIN [Dim].[Patients] P
ON A.id_Patient=P.[PatientKey]
AND P.[FirstName] like '%PHA_Relat_EncAT%'
INNER JOIN [Dim].[CareProviders] C
ON provider_Related=C.CareProviderKey
AND A.attrib_RelationType = @RelationTipe
ORDER BY P.[FirstName],date_From