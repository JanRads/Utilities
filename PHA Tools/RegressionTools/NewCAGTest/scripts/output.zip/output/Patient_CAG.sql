select MP.[PatientId_Root] as PatientId_Root, MP.[PatientId_Extension] as PatientId_Extension, MP.[EnterprisePatientId] as EnterprisePatientId, P.PatientMPIID as PatientMPIID,
P.FullName as FullName, P.FirstName as FirstName, P.LastName as LastName, P.MiddleName as MiddleName,
DATEPART(yyyy,TimeOfBirth)*10000+DATEPART(MM,TimeOfBirth)*100+DATEPART(DD,TimeOfBirth) as TimeOfBirth,
DATEPART(yyyy,TimeOfDeath)*10000+DATEPART(MM,TimeOfDeath)*100+DATEPART(DD,TimeOfDeath) as TimeOfDeath, 
P.AddressLine1 as AddressLine1, P.AddressLine2 as AddressLine2, P.MobilePhone as MobilePhone, P.HomeEmail as HomeEmail,
P.[GenderCode] as GenderCode, P.[GenderCodeSystem] as GenderCodeSystem
from [dbmClinicalAnalyticsGateway].[MasterData].[Patient] P
inner join [dbmClinicalAnalyticsGateway].[MasterData].[PatientIdentifier] MP
on P.EnterprisePatientId = MP.EnterprisePatientId 
where MP.PatientId_Extension LIKE N'PHA_EncAT_P%' 
order by MP.[PatientId_Root], MP.[PatientId_Extension]




