﻿<#
    SetupWindowsRolesFeatures.ps1
    Purpose:
        To automate the installation of basic Windows Roles and Features for PHA and MicroStrategy servers.

    Known Issues:
        Some Windows Server 2012 images do not come with the .NET 3.5 Framework components.  This requires 
        an external msi file from Microsoft and plugging in the location reference of said file.
#>
param(
    [Bool]$includeNET35=$false,
    [String]$Net35Path = ""
)

#Variables
[Bool]$restart = $false


#List of Windows Features
$features = @(
"FileAndStorage-Services"
,"File-Services"
,"FS-FileServer"
,"Storage-Services"
,"Web-Server"
,"Web-WebServer"
,"Web-Common-Http"
,"Web-Default-Doc"
,"Web-Dir-Browsing"
,"Web-Http-Errors"
,"Web-Static-Content"
,"Web-Http-Redirect"
,"Web-Health"
,"Web-Http-Logging"
,"Web-Log-Libraries"
,"Web-Performance"
,"Web-Stat-Compression"
,"Web-Dyn-Compression"
,"Web-Security"
,"Web-Filtering"
,"Web-Basic-Auth"
,"Web-CertProvider"
,"Web-IP-Security"
,"Web-Url-Auth"
,"Web-Windows-Auth"
,"Web-App-Dev"
,"Web-Net-Ext45"
,"Web-AppInit"
,"Web-Asp-Net45"
,"Web-ISAPI-Ext"
,"Web-ISAPI-Filter"
,"Web-Mgmt-Tools"
,"Web-Mgmt-Console"
,"Web-Scripting-Tools"
,"Web-Mgmt-Service"
,"NET-Framework-45-Features"
,"NET-Framework-45-Core"
,"NET-Framework-45-ASPNET"
,"NET-WCF-Services45"
,"NET-WCF-TCP-PortSharing45"
,"RDC"
,"FS-SMB1"
,"User-Interfaces-Infra"
,"Server-Gui-Mgmt-Infra"
,"Server-Gui-Shell"
,"PowerShellRoot"
,"PowerShell"
,"PowerShell-ISE"
,"WoW64-Support"
)

# Add needed Features that are not installed
If ((Get-WindowsFeature $features | Where-Object {$_.Installed -eq $False}).Count -gt 0){
    $results = Install-WindowsFeature -Name $(Get-WindowsFeature $features | Where-Object {$_.Installed -eq $False})
    If($results.RestartNeeded -ne "No"){$restart=$true}
}

# Uninstall unneeded Features that are present
If ((Get-WindowsFeature | Where-Object {$_.Name -notin $features -and $_.Installed -eq $True}).Count -gt 0){
    Uninstall-WindowsFeature -Name $(Get-WindowsFeature | Where-Object {$_.Name -notin $features -and $_.Installed -eq $True})
    If($results.RestartNeeded -ne "No"){$restart=$true}
}

# Add .NET 3.5 Framework Features, if needed
If($includeNET35){
    $features3_5 = @(
    "NET-Framework-Features"
    ,"NET-Framework-Core"
    ,"PowerShell-V2"
    ,"Web-Net-Ext"
    ,"Web-ASP"
    ,"Web-Asp-Net"
    )

    If ((Get-WindowsFeature $features3_5 | Where-Object {$_.Installed -eq $False}).Count -gt 0){
        Install-WindowsFeature -Name $(Get-WindowsFeature $features3_5 | Where-Object {$_.Installed -eq $False}) -source $Net35Path
        If($results.RestartNeeded -ne "No"){$restart=$true}
    }
}

If ($restart){
    # Prompt user to reboot machine
    # Popup settings
    $caption = "System Reboot";
    $message = "The installation requires a reboot of this machine. Are you ready to reboot?";
    $results = New-Object System.Management.Automation.Host.ChoiceDescription "&Restart","Restart";
    $cancel = New-Object System.Management.Automation.Host.ChoiceDescription "&Cancel","Cancel";
    $choices = [System.Management.Automation.Host.ChoiceDescription[]]($results,$cancel);

    # Write-Host "Restart needed. Restart Value: $($results.RestartNeeded)"
    # Show popup to user
    $answer = $host.ui.PromptForChoice($caption,$message,$choices,0)
    # Process user's response
    switch ($answer){
        0 {"Restarting server"; Restart-Computer}
        1 {"Restart cancelled"; break}
    }
} Else {
    [System.Windows.Forms.Messagebox]::Show(“The process finished successfully. The Roles and Features for this server are set.”,"Results")
}


