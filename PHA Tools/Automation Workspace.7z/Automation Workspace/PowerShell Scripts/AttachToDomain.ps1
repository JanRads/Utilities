﻿<#
    AttachToDomain.ps1
    Purpose:
        1. Set the DNS IP address to the Domain Controller's IP address
        2. Add the server to the domain

    Notes:
    This script is a 2-step process as each section needs the server to reset.
        1. After setting the DNS, connection to the server will be lost. 
            In Azure, do a restart of the VM. 
            Then log back in to the server and rerun the script
        2. After adding the server to the domain, the server will reboot.
#>

# ========== Set DNS IP Address ==========
#DNS Variables
[String]$dnsIP='172.18.1.4'
[String]$dnsCurrent=''

$dnsCurrent=(Get-DnsClientServerAddress -AddressFamily IPv4 -InterfaceIndex 14).ServerAddresses
if($dnsCurrent -ne $dnsIP){
    #Write-Host 'Changing DNS IP address'
    Set-DnsClientServerAddress -InterfaceIndex 14 –ServerAddresses ($dnsIP,””) -Confirm 
    Exit
} Else {
    [System.Windows.Forms.Messagebox]::Show(“The DNS IP setting is already set to $($dnsIP).”,"Results")
}


# ========== Add Server to Domain ==========
#Domain Variables
[String]$domain='PHAQA.com'
[Bool]$AddDomain=$true

# Check to see if the server is already attached to the $domain
if((Get-WmiObject -Class Win32_ComputerSystem).PartOfDomain ){
    # Name of Domain computer is attached to
    [PSObject]$existingDomainName=(Get-WmiObject -Class Win32_ComputerSystem | Select Domain)
    if($existingDomainName.Domain -eq $domain){
        $AddDomain=$false #Server is already attached to the domain
    }
}
# Add Server to Domain
if($AddDomain){
    Add-Computer -DomainName PHAQA.com -Credential PHAQA\PHADB -Restart
    #Add-Computer -WorkgroupName PHAQA -Credential PHAQA\PHADB -Restart 
    Exit
} Else {
    [System.Windows.Forms.Messagebox]::Show(“This server is already attached to the $($domain) domain.”,"Results")
}

#Cleanup: Remove all Variables
Remove-Variable -Name * -ErrorAction SilentlyContinue

