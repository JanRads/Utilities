﻿<#
    WindowsSettings.ps1
    Purpose:
        To make any miscellaneous modifications to settings
#>
<#
## Check for existing registries
If (Get-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name SCRNSAVE.EXE -ErrorAction SilentlyContinue) {
   Write-Output 'Value exists'
} Else {
    Write-Output 'Value DOES NOT exist'
}
#>
## Set the UAC RunAs Administrator function so that there is no prompt when an administrator runs an application in that mode
If (Get-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name ConsentPromptBehaviorAdmin -ErrorAction SilentlyContinue) {
	Set-ItemProperty -path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System' -Name 	ConsentPromptBehaviorAdmin -Value 0 -Force
} Else {
	New-ItemProperty -Path HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System -Name ConsentPromptBehaviorAdmin -Value 0 -Force
}

## Set Mouse to snap to default button
If (Get-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name SnapToDefaultButton -ErrorAction SilentlyContinue) {
	Set-ItemProperty -path 'HKCU:\Control Panel\Mouse' -Name SnapToDefaultButton -value 1 
} Else {
	New-ItemProperty-ItemProperty -path 'HKCU:\Control Panel\Mouse' -Name SnapToDefaultButton -value 1 -Force
}

## Change Time Zone
if ([System.TimeZone]::CurrentTimeZone -ne 'Eastern Standard Time') {
    tzutil.exe /s 'Eastern Standard Time'
}

## Disable Shutdown Event Tracker prompt (Windows Server 2016)
If (Get-ItemProperty -Path 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Reliability' -Name ShutdownReasonOn -ErrorAction SilentlyContinue) {
	Set-ItemProperty -Path 'registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Reliability' -Name ShutdownReasonOn -Value 0 -Force
} Else {
	New-ItemProperty -Path 'registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Reliability' -Name ShutdownReasonOn -Value 0 -Force
}
