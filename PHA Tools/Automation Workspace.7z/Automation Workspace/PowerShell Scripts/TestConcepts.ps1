﻿<#
    TestConcepts.ps1
    Purpose:
        To test how to accomplish tasks in PowerShell
#>

## Get user input
$Server = Read-Host -Prompt 'Input your server name'
$User = Read-Host -Prompt 'Input the user name'
$Date = Get-Date
Write-Host "You input server '$Server' and '$User' on '$Date'" 

## Prompt user to reboot machine
## Popup settings
$caption = "System Reboot";
$message = "The installation requires a reboot of this machine. Are you ready to reboot?";
$restart = New-Object System.Management.Automation.Host.ChoiceDescription "&Restart","Restart";
$cancel = New-Object System.Management.Automation.Host.ChoiceDescription "&Cancel","Cancel";
$choices = [System.Management.Automation.Host.ChoiceDescription[]]($restart,$cancel);
## Popup to user
$answer = $host.ui.PromptForChoice($caption,$message,$choices,0)
## Process user's response
switch ($answer){
    0 {"You entered restart"; Restart-Computer -WhatIf}
    1 {"You entered cancel"; break}
}

## Send a simple popup message
[System.Windows.Forms.Messagebox]::Show(“The process finished successfully. The Roles and Features for this server are set.”,"Results")


## Check for installed software
[Bool]$IsInstalled
Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | 
    Select-Object DisplayName, Name, DisplayVersion, Publisher, InstallDate | 
    Format-Table –AutoSize
#DisplayName='SQL Server 2016 Management Studio'
#DisplayVersion=13.0.1601.5
## Check for installed software
# Quick Response but only checks Wow6432Node
$IsInstalled=(Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | 
    Select-Object DisplayName | 
    Where-Object { $_.DisplayName -eq “SQL Server 2016 Management Studio”}).Count -gt 0
Write-Host $IsInstalled

# Slow Response but checks 32 bit and Wow6432Node
$IsInstalled=(Get-WmiObject -Class Win32_Product | 
    Select-Object Name | 
    Where-Object { $_.Name -eq “SQL Server 2016 Management Studio”}).Count -gt 0
Write-Host $IsInstalled


#Add computer to domain
[String]$domain='PHAQA.com'
[Bool]$AddDomain=$true
# PartOfDomain (boolean Property)
if((Get-WmiObject -Class Win32_ComputerSystem).PartOfDomain ){
    # Name of Domain computer is attached to
    if(Get-WmiObject -Class Win32_ComputerSystem | Select Domain -eq $domain){
        $AddDomain=$false
    }
}
if($AddDomain){
    Add-Computer -DomainName PHAQA.com -Credential PHAQA\PHADB -Restart -WhatIf
    #Add-Computer -WorkgroupName PHAQA -Credential PHAQA\PHADB -Restart 
}

#Set DNS Setting
[String]$dnsIP='172.18.1.4'
[String]$dnsCurrent=''
$dnsCurrent=(Get-DnsClientServerAddress -AddressFamily IPv4 -InterfaceIndex 14).ServerAddresses
if($dnsCurrent -ne $dnsIP){
    Write-Host 'Changing DNS IP address'
    Set-DnsClientServerAddress -InterfaceIndex 14 –ServerAddresses ($dnsIP,””) -Confirm -Whatif
}

