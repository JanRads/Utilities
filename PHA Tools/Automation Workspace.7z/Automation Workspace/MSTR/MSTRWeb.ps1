﻿<#
    MSTR-Web.ps1
    Purpose:
        To remind user of available ACG user accounts for MSTR testing

    Keep Command Window Open
        powershell -noExit
        powershell Read-Host -Prompt "Press Enter to exit"

#>

#[Void][Load][System.Windows.Forms.Messagebox]
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Messagebox]::Show(“List of available ACG user accounts in MicroStrategy
    • ACGAdmin
    • ACGPro
    • ACGAnalyst
    • ACGReporter
”,"QA's Cage")

#Start-Process -FilePath Chrome -ArgumentList www.allscripts.com 
Start-Process -FilePath Chrome -ArgumentList http://pha181-az1-web/MicroStrategy/asp


<#
Purpose: Automate install processes
    Create ODBC connections
    Setup Intelligence Services to run via an established ODBC connection
        Other variables/settings are needed


#>