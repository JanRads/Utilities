﻿<#
    InstallSQLServer.ps1
    Purpose:
        To automate the installation of SQL server 2016: Shared Features and Instance Features.
        To automate the installation of the SSMS tool

    Notes:
        The SQL configuration file (PHAConfigurationFile.ini) must be in the folder where the iso file is.
            - The location of this is stated in $ISOpath variable.
        Depending on the environment, you may want to edit the list of SQL admins listed in the PHAConfigurationFile.ini file
            - This is under the SQLSYSADMINACCOUNTS option.
#>


# ========== SQL Server Installation ==========
#Variables for SQL Server Installation
[Bool]$restart = $false
[Bool]$IsInstalled=$false
[String]$ISOdrive='' #This is set automatically later in the script
[String]$ISOpath='C:\Installation Tools\SQL Server 2016\'
[String]$ISOfile='en_sql_server_2016_standard_with_service_pack_1_x64_dvd_9540929.iso'
[String]$SApwd='1Qaz2wsx3edc'
[String]$SQLInstance='INST01'

# Get drive letter of mounted SQL installation image
$ISOdrive = (Get-DiskImage -ImagePath ($ISOpath+$ISOfile) | Get-Volume).DriveLetter
if($ISOdrive -eq ''){
    #Mount ISO
    Mount-DiskImage -ImagePath ($ISOpath+$ISOfile) -StorageType ISO 
    $ISOdrive = (Get-DiskImage -ImagePath ($ISOpath+$ISOfile) | Get-Volume).DriveLetter
}
$ISOdrive += ':\'

# Load PowerShell for SQL module, if not already loaded
if (-not(Get-Module -name 'SQLPS')) {
  if (Get-Module -ListAvailable | Where-Object {$_.Name -eq 'SQLPS' }) {
        Push-Location # The SQLPS module load changes location to the Provider, so save the current location
        Import-Module -Name 'SQLPS' -DisableNameChecking
        Pop-Location # Now go back to the original location
    }
}

# Check for installed instance and do installation
[PSobject]$instance=Get-ChildItem -Path "SQLSERVER:\SQL\$env:computername" -EA SilentlyContinue | Select-Object -Property InstanceName
if ($instance.PSobject.Properties.name -notmatch "InstanceName" -or $instance -eq ''){
    if($instance.InstanceName -eq $SQLInstance -or $instance -eq ''){
        # Run SQL Setup
        $setup=$ISOdrive+'Setup.exe'
        # Note: Adding quotes around the config file will generate an error
        $args='/ConfigurationFile='+$ISOpath+'PHAConfigurationFile.ini|/SAPWD="'+$SApwd+'"|/IAcceptSQLServerLicenseTerms|/QS'
        $argsSQL=$args.Split("|")
        &$setup $argsSQL

        $restart=$true
    }
}


########## UNINSTALL UTILITY ##########
<#
# This is a utility to UNINSTALL SQL Server and INST01
$delargList='/Action=Uninstall|/FEATURES=SQL,CONN,IS,BC,SDK,SNAC_SDK|/INSTANCENAME=INST01|/Q'
$delargs=$delargList.Split("|")
&$setup $delargs
#>

# Dismount ISO image
Dismount-DiskImage -ImagePath ($ISOpath+$ISOfile) -StorageType ISO

# ========== SSMS Installation ==========
$IsInstalled=(Get-WmiObject -Class Win32_Product | 
    Select-Object Name | 
    Where-Object { $_.Name -eq “SQL Server 2016 Management Studio”}).Count -gt 0
#Write-Host $IsInstalled

if (!$IsInstalled){
    # Set file and folder path for SSMS installer .exe
    $SSMSpath="C:\Installation Tools\SQL Server 2016\"
    $SSMSfile="$SSMSpath\SSMS-Setup-ENU.exe"
    #Write-Host Test-Path $SSMSfile

    #If SSMS not present, download
    if (!(Test-Path $SSMSfile)){
    $URL = "https://download.microsoft.com/download/3/1/D/31D734E0-BFE8-4C33-A9DE-2392808ADEE6/SSMS-Setup-ENU.exe"
    $clnt = New-Object System.Net.WebClient
    $clnt.DownloadFile($url,$SSMSfile)
    }
 
    # Start the SSMS installer
    $argList = "/Install|/Norestart|/Logs log.txt"
    $argsSSMS = $argList.Split("|")
    &$SSMSfile $argsSSMS | Out-Null

    $restart=$true
}


###### Final Popup Message ######
If ($restart){
    # Prompt user to reboot machine
    # Popup settings
    $caption = "System Reboot";
    $message = "The installation requires a reboot of this machine. Are you ready to reboot?";
    $results = New-Object System.Management.Automation.Host.ChoiceDescription "&Restart","Restart";
    $cancel = New-Object System.Management.Automation.Host.ChoiceDescription "&Cancel","Cancel";
    $choices = [System.Management.Automation.Host.ChoiceDescription[]]($results,$cancel);

    # Write-Host "Restart needed. Restart Value: $($results.RestartNeeded)"
    # Show popup to user
    $answer = $host.ui.PromptForChoice($caption,$message,$choices,0)
    # Process user's response
    switch ($answer){
        0 {"Restarting server"; Restart-Computer}
        1 {"Restart cancelled"; break}
    }
} Else {
    [System.Windows.Forms.Messagebox]::Show(“SQL Server and SSMS have already been installed on this server.”,"Results")
}



#Cleanup: Remove all Variables
Remove-Variable -Name * -ErrorAction SilentlyContinue
